package com.example.piceditor

import android.annotation.SuppressLint
import android.graphics.PointF
import android.os.Bundle
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.get
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.piceditor.databinding.ActivityMainBinding

import kotlin.math.PI
import kotlin.math.atan
import kotlin.math.sqrt
class MainActivity : AppCompatActivity(R.layout.activity)