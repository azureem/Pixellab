package com.example.piceditor

 data class EmojiData(
     var id:Int,
     var image:Int
 )